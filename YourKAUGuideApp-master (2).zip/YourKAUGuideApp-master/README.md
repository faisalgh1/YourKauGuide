# YourKAUGuideApp

implementing a smart chatbot that can provide accurate and timely answers to students' inquiries quickly and easily.
This will be achieved by implementing solutions that make information easily accessible to students

To improve the FCIT community’s experience using an AI chatbot.

Arabic natural language processing will be used to accurately and quickly interact 

Datasets from Twitter’s and Webpage`s FCIT will be utilized to answer the questions 

Deep learning models will be used to train the chatbot and increase the accuracy of answers.

Front end : Android studio Java
Back end : Firebase   , Pycharm , Python anywhere
Libraries : torch, ISRI, Numpy ,NLTK , Snscrape

App Answer question in those domain :
General Question like greating and thanks
Question related to Fcit like plans , traks , majors , activity , doctor emails , exams seclude , laps location and more
Other general kau Question like registration , delete terms  and more
